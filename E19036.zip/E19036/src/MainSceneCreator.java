import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.FileInputStream;
import java.io.FileNotFoundException;


public class MainSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {
	
	//dilosi FlowPane, eikonwn kai Buttons
	FlowPane rootFlowPane; 
	Image cityI,storeI,clientI,vehicleI,rentalI;
	Button cityBtn, storeBtn, clientBtn, vehicleBtn, rentalBtn;
	
	public MainSceneCreator (double width, double height) {
		super(width, height);
		
		FileInputStream cityFIS = null, storeFIS = null, clientFIS = null, vehicleFIS = null, rentalFIS = null;
		try {
			cityFIS = new FileInputStream("img/city.png");
			storeFIS = new FileInputStream("img/store.png");
			clientFIS = new FileInputStream("img/client.png");
			vehicleFIS = new FileInputStream("img/vehicle.png");
			rentalFIS = new FileInputStream("img/rental.png");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
        cityI = new Image(cityFIS); 
        storeI = new Image(storeFIS); 
        clientI = new Image(clientFIS); 
        vehicleI = new Image(vehicleFIS); 
        rentalI = new Image(rentalFIS); 
        
        ImageView cityIV = new ImageView(cityI);
        cityIV.setFitWidth(70);
        cityIV.setFitHeight(70);
        
        ImageView storeIV = new ImageView(storeI);
        storeIV.setFitWidth(70);
        storeIV.setFitHeight(70);
        
        ImageView clientIV = new ImageView(clientI);
        clientIV.setFitWidth(70);
        clientIV.setFitHeight(70);
        
        ImageView vehicleIV = new ImageView(vehicleI);
        vehicleIV.setFitWidth(70);
        vehicleIV.setFitHeight(70);
        
        ImageView rentalIV = new ImageView(rentalI);
        rentalIV.setFitWidth(70);
        rentalIV.setFitHeight(70);
		
		rootFlowPane = new FlowPane();
		cityBtn = new Button("City", cityIV);
		storeBtn = new Button("Store", storeIV);
		clientBtn = new Button("Client", clientIV);
		vehicleBtn = new Button("Vehicle", vehicleIV);
		rentalBtn = new Button("Vehicle Rental", rentalIV);
		
		cityBtn.setOnMouseClicked(this);
		storeBtn.setOnMouseClicked(this);
		clientBtn.setOnMouseClicked(this);
		vehicleBtn.setOnMouseClicked(this);
		rentalBtn.setOnMouseClicked(this);
		
		rootFlowPane.setHgap(10);
		rootFlowPane.setAlignment(Pos.CENTER);
		
		rootFlowPane.getChildren().add(cityBtn);
		rootFlowPane.getChildren().add(storeBtn);
		rootFlowPane.getChildren().add(clientBtn);
		rootFlowPane.getChildren().add(vehicleBtn);
		rootFlowPane.getChildren().add(rentalBtn);
		
	}
	
	public Scene createScene() { return new Scene(rootFlowPane, width, height);}
	
	public void handle(MouseEvent event) {
		//edw ginetai to click me to opoio o xristis epilegei ena apo ta 5 windows
		if (event.getSource() == cityBtn) {
			Main.mainStage.setTitle("City Window");
			Main.mainStage.setScene(Main.cityScene);
		}
		
		if (event.getSource() == storeBtn) {
			Main.mainStage.setTitle("Store Window");
			StoreSceneCreator.updateCityCombo();
			Main.mainStage.setScene(Main.storeScene);
		}
		
		if (event.getSource() == clientBtn) {
			Main.mainStage.setTitle("Client Window");
			Main.mainStage.setScene(Main.clientScene);
		}
		
		if (event.getSource() == vehicleBtn) {
			Main.mainStage.setTitle("Vehicle Window");
			Main.mainStage.setScene(Main.vehicleScene);
		}
		
		if (event.getSource() == rentalBtn) {
			Main.mainStage.setTitle("Rental Window");
			Main.mainStage.setScene(Main.rentalScene);
		}
		
	}

}