public class Client {

private String AT; //dilosi metablhtwn 
private String adeia;
private String onoma; 
private String epitheto; 
private String email; 
private String address; 
private String phone; 

//constructor
public Client(String AT, String adeia, String onoma, String epitheto, String email, String address, String phone) {
	super();
	this.AT = AT;
	this.adeia = adeia;
	this.onoma = onoma;
	this.epitheto = epitheto;
	this.email = email;
	this.address = address;
	this.phone = phone;
}

//getters kai setters
public String getAT() {
	return AT;
}
public void setAT(String aT) {
	AT = aT;
}
public String getAdeia() {
	return adeia;
}
public void setAdeia(String adeia) {
	this.adeia = adeia;
}
public String getOnoma() {
	return onoma;
}
public void setOnoma(String onoma) {
	this.onoma = onoma;
}
public String getEpitheto() {
	return epitheto;
}
public void setEpitheto(String epitheto) {
	this.epitheto = epitheto;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}

}
