import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;

public class Main extends Application {

	final int width = 1200 , height = 480 ; 
	//dilosi twn stages
	static Stage mainStage; 
	static 	Scene mainScene, cityScene, storeScene, clientScene, vehicleScene, rentalScene;
	
	public static void main(String[] args) { launch(args); }
	
	public void start(Stage primaryStage) {
		
		//simiourgia twn parathyrwn gia na ta epilxei o xristis
		mainStage = primaryStage;
		SceneCreator mainSceneCreator = new MainSceneCreator(width , height);
		mainScene = mainSceneCreator.createScene();
		
		SceneCreator citySceneCreator = new CitySceneCreator(width , height);
		cityScene = citySceneCreator.createScene();
		System.out.println(cityScene);
		
		SceneCreator storeSceneCreator = new StoreSceneCreator(width , height);
		storeScene = storeSceneCreator.createScene();
		
		SceneCreator vehicleSceneCreator = new VehicleSceneCreator(width , height);
		vehicleScene = vehicleSceneCreator.createScene();
		
		SceneCreator clientSceneCreator = new ClientSceneCreator(width , height);
		clientScene = clientSceneCreator.createScene();
		
		SceneCreator rentalSceneCreator = new RentalSceneCreator(width , height);
		rentalScene = rentalSceneCreator.createScene();
				
		primaryStage.setTitle("Car Rental Service ");
		primaryStage.setScene(mainScene);
		primaryStage.show();
		
	}

}

