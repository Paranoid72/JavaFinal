public class Rental {

private String rentalCode; //dilosi metablhtwn
private String rentVehicle; 
private String Sparalabh; 
private String Sepistrofh; 
private String rentDate; 
private String hour;  
private double Fcost; 

//constructor
public Rental(String rentalCode, String rentVehicle, String sparalabh, String sepistrofh, String rentDate, String hour,
		double fcost) {
	super();
	this.rentalCode = rentalCode;
	this.rentVehicle = rentVehicle;
	Sparalabh = sparalabh;
	Sepistrofh = sepistrofh;
	this.rentDate = rentDate;
	this.hour = hour;
	Fcost = fcost;
}

//getters kai setters
public String getRentalCode() {
	return rentalCode;
}
public void setRentalCode(String rentalCode) {
	this.rentalCode = rentalCode;
}
public String getRentVehicle() {
	return rentVehicle;
}
public void setRentVehicle(String rentVehicle) {
	this.rentVehicle = rentVehicle;
}
public String getSparalabh() {
	return Sparalabh;
}
public void setSparalabh(String sparalabh) {
	Sparalabh = sparalabh;
}
public String getSepistrofh() {
	return Sepistrofh;
}
public void setSepistrofh(String sepistrofh) {
	Sepistrofh = sepistrofh;
}
public String getRentDate() {
	return rentDate;
}
public void setRentDate(String rentDate) {
	this.rentDate = rentDate;
}
public String getHour() {
	return hour;
}
public void setHour(String hour) {
	this.hour = hour;
}
public double getFcost() {
	return Fcost;
}
public void setFcost(double fcost) {
	Fcost = fcost;
}

}