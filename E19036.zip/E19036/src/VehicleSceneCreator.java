import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import java.util.ArrayList;
import java.util.List;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;

public class VehicleSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {

	boolean temp = true; // an to radiobutton gia twowheel einai epilegmeno
	String tempAK = ""; // exei to AK tou epilegmenou vehicle

	//  List of vehicles
	static ArrayList<Vehicle> vehicleList; 
	//	Flow Pane
	FlowPane buttonFlowPane;
	//	Grid Panes
	GridPane rootGridPane, inputFieldsPane;
	//	Second Scene buttons
	Button newVehicleBtn, searchVehicleBtn, showVehicleBtn,
	updateVehicleBtn, deleteVehicleBtn, backBtn, clearBtn;
	//	Second scene labels
	Label searchLbl, typeLbl, fLbl, sLbl, AKLbl, modelLbl, katigoriaLbl, fueltypeLbl,kybikaLbl, rentCostLbl;
	//	Second scene TextFields
	TextField fField, sField, AKField, modelField, katigoriaField, fueltypeField,kybikaField, rentCostField;
	//	TableView
	TableView<Vehicle> vehicleTableView;
	RadioButton twowheelrb, carrb;
	ToggleGroup wheelgroup = new ToggleGroup();

	ComboBox searchComboBox;

	public VehicleSceneCreator(double width, double height) {
		super(width, height);

		String options[] = { "TwoWheeled", "Car" }; 
		searchComboBox =  new ComboBox(FXCollections.observableArrayList(options));

		//  dimiourgia Labels kai Fields
		vehicleList = new ArrayList<>();
		rootGridPane = new GridPane();
		buttonFlowPane = new FlowPane();

		typeLbl = new Label("Type: ");

		searchLbl = new Label("Search by type: ");
		fField = new TextField();
		fLbl = new Label("Seat height: ");
		sField = new TextField();
		sLbl = new Label("Package system: ");

		AKLbl = new Label("Arithmos Kukloforias: ");
		AKField = new TextField();
		modelLbl = new Label("Vehicle Model: ");
		modelField = new TextField();
		katigoriaLbl = new Label("Category: ");
		katigoriaField = new TextField();
		fueltypeLbl = new Label("Fuel Type: ");
		fueltypeField = new TextField();
		kybikaLbl = new Label("Cubism: ");
		kybikaField = new TextField();
		rentCostLbl = new Label("Vehicle Rent Cost: ");
		rentCostField = new TextField();

		twowheelrb = new RadioButton("Two Wheel");
		twowheelrb.setToggleGroup(wheelgroup);
		twowheelrb.setSelected(true);

		carrb = new RadioButton("Car");
		carrb.setToggleGroup(wheelgroup);

		clearBtn = new Button("Clear Fields");
		newVehicleBtn = new Button("New Vehicle");
		searchVehicleBtn = new Button("Search");
		showVehicleBtn = new Button("Show All Vehicles");
		updateVehicleBtn = new Button("Update");
		deleteVehicleBtn = new Button("Delete");
		backBtn = new Button("Go Back");
		inputFieldsPane = new GridPane();
		vehicleTableView = new TableView<>();

		//  Attach events
		backBtn.setOnMouseClicked(this);
		newVehicleBtn.setOnMouseClicked(this);
		searchVehicleBtn.setOnMouseClicked(this);
		showVehicleBtn.setOnMouseClicked(this);
		updateVehicleBtn.setOnMouseClicked(this);
		deleteVehicleBtn.setOnMouseClicked(this);
		vehicleTableView.setOnMouseClicked(this);
		clearBtn.setOnMouseClicked(this);

		//  Customize buttonFlowPane
		buttonFlowPane.setHgap(10);
		buttonFlowPane.getChildren().add(newVehicleBtn);
		buttonFlowPane.getChildren().add(searchVehicleBtn);
		buttonFlowPane.getChildren().add(showVehicleBtn);
		buttonFlowPane.getChildren().add(updateVehicleBtn);
		buttonFlowPane.getChildren().add(deleteVehicleBtn);
		buttonFlowPane.getChildren().add(clearBtn);
		buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);

		// Customize inputFieldsPane
		inputFieldsPane.setAlignment(Pos.TOP_RIGHT);
		inputFieldsPane.setVgap(10);
		inputFieldsPane.setHgap(10);

		inputFieldsPane.add(typeLbl, 0, 0);
		inputFieldsPane.add(twowheelrb, 1, 0);
		inputFieldsPane.add(carrb, 1, 1);

		inputFieldsPane.add(fLbl, 0, 2);
		inputFieldsPane.add(fField, 1, 2);
		inputFieldsPane.add(sLbl, 0, 3);
		inputFieldsPane.add(sField, 1, 3);
		inputFieldsPane.add(AKLbl, 0, 4);
		inputFieldsPane.add(AKField, 1, 4);
		inputFieldsPane.add(modelLbl, 0, 5);
		inputFieldsPane.add(modelField, 1, 5);
		inputFieldsPane.add(katigoriaLbl, 0, 6);
		inputFieldsPane.add(katigoriaField, 1, 6);
		inputFieldsPane.add(fueltypeLbl, 0, 7);
		inputFieldsPane.add(fueltypeField, 1, 7);
		inputFieldsPane.add(kybikaLbl, 0, 8);
		inputFieldsPane.add(kybikaField, 1, 8);
		inputFieldsPane.add(rentCostLbl, 0, 9);
		inputFieldsPane.add(rentCostField, 1, 9);
		inputFieldsPane.add(searchLbl, 0, 10);
		inputFieldsPane.add(searchComboBox, 1, 10);

		// Customize rootGridPane
		rootGridPane.setVgap(10);
		rootGridPane.setHgap(10);
		rootGridPane.add(inputFieldsPane, 1, 0);
		rootGridPane.add(vehicleTableView, 0, 0);
		rootGridPane.add(buttonFlowPane, 0, 2);
		rootGridPane.add(backBtn, 1, 2);

		//  Customize vehicleTableView
		TableColumn<Vehicle, String> AKColumn = new TableColumn<>("Ar. Kykloforias");
		AKColumn.setCellValueFactory(new PropertyValueFactory<>("AK"));
		vehicleTableView.getColumns().add(AKColumn);

		TableColumn<Vehicle, String> modelColumn = new TableColumn<>("Model");
		modelColumn.setCellValueFactory(new PropertyValueFactory<>("model"));
		vehicleTableView.getColumns().add(modelColumn);

		TableColumn<Vehicle, String> katigoriaColumn = new TableColumn<>("Category");
		katigoriaColumn.setCellValueFactory(new PropertyValueFactory<>("katigoria"));
		vehicleTableView.getColumns().add(katigoriaColumn);

		TableColumn<Vehicle, String> fueltypeColumn = new TableColumn<>("Fuel Type");
		fueltypeColumn.setCellValueFactory(new PropertyValueFactory<>("fuel"));
		vehicleTableView.getColumns().add(fueltypeColumn);

		TableColumn<Vehicle, String> kybikaColumn = new TableColumn<>("Cubism");
		kybikaColumn.setCellValueFactory(new PropertyValueFactory<>("kybika"));
		vehicleTableView.getColumns().add(kybikaColumn);

		TableColumn<Vehicle, String> rentCostColumn = new TableColumn<>("Rent Cost");
		rentCostColumn.setCellValueFactory(new PropertyValueFactory<>("rentCost"));
		vehicleTableView.getColumns().add(rentCostColumn);

		TableColumn<Vehicle, String> seatsnumberColumn = new TableColumn<>("Seats");
		seatsnumberColumn.setCellValueFactory(new PropertyValueFactory<>("seatsnumber"));
		vehicleTableView.getColumns().add(seatsnumberColumn);

		TableColumn<Vehicle, String> doorsnumberColumn = new TableColumn<>("Doors");
		doorsnumberColumn.setCellValueFactory(new PropertyValueFactory<>("doorsnumber"));
		vehicleTableView.getColumns().add(doorsnumberColumn);

		TableColumn<Vehicle, String> heightColumn = new TableColumn<>("Seat Height");
		heightColumn.setCellValueFactory(new PropertyValueFactory<>("height"));
		vehicleTableView.getColumns().add(heightColumn);

		TableColumn<Vehicle, String> packageSystemColumn = new TableColumn<>("Package System");
		packageSystemColumn.setCellValueFactory(new PropertyValueFactory<>("packageSystem"));
		vehicleTableView.getColumns().add(packageSystemColumn);


		twowheelrb.selectedProperty().addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> obs, Boolean wasPreviouslySelected, Boolean isNowSelected) {
				if (isNowSelected) { 
					temp = true;
					fLbl.setText("Seat height: ");
					sLbl.setText("Package system: ");
				} else {
					temp = false;
					fLbl.setText("Seats' number: ");
					sLbl.setText("Doors' number: ");
				}
				clearTextFields(false);
			}
		});
	}

	@Override
	public Scene createScene() {
		return new Scene(rootGridPane, width, height);
	}

	@Override
	public void handle(MouseEvent event) {
		if (event.getSource() == backBtn) {
			Main.mainStage.setTitle("Car Rental Service ");
			Main.mainStage.setScene(Main.mainScene);
		}

		if (event.getSource() == newVehicleBtn) {
			//diavazw ayta pou exei eisagei o xristis
			String AK = AKField.getText();
			String model = modelField.getText();
			String katigoria = katigoriaField.getText();
			String fueltype = fueltypeField.getText();
			String kybika = kybikaField.getText();
			String rentCost = rentCostField.getText();
			String f = fField.getText();
			String s = sField.getText();

			//elegxw oti exoun simplirwthei ta pedia ayta
			if (AK.length() == 0) return;
			if (model.length() == 0) return;
			if (katigoria.length() == 0) return;
			if (fueltype.length() == 0) return;
			if (kybika.length() == 0) return;
			if (rentCost.length() == 0) return;
			if (f.length() == 0) return;
			if (s.length() == 0) return;
			double k = Double.parseDouble(kybika);
			double r = Double.parseDouble(rentCost);

			if (temp == true) {
				double ff = Double.parseDouble(f);
				Vehicle v = new TwoWheeled(AK, model, katigoria, fueltype,k, r, ff ,s );
				vehicleList.add(v);
			}
			else {
				int ff = Integer.parseInt(f);
				int ss = Integer.parseInt(s);
				Vehicle v = new Car(AK, model, katigoria, fueltype,k, r, ff ,ss );
				vehicleList.add(v);
			}
			tableSync();
			clearTextFields(true);
		}

		if (event.getSource() == clearBtn) {
			clearTextFields(true);
		}

		if (event.getSource() == updateVehicleBtn) {
			// kanei update ta pedia pou allazei o xristis
			String AK = AKField.getText();
			String model = modelField.getText();
			String katigoria = katigoriaField.getText();
			String fueltype = fueltypeField.getText();
			String kybika = kybikaField.getText();
			String rentCost = rentCostField.getText();
			String f = fField.getText();
			String s = sField.getText();

			//elegxw oti exoun simplirwthei ta pedia ayta
			if (AK.length() == 0) return;
			if (model.length() == 0) return;
			if (katigoria.length() == 0) return;
			if (fueltype.length() == 0) return;
			if (kybika.length() == 0) return;
			if (rentCost.length() == 0) return;
			if (f.length() == 0) return;
			if (s.length() == 0) return;
			double k = Double.parseDouble(kybika);
			double r = Double.parseDouble(rentCost);


			if (!tempAK.equals("")) {
				updateVehicle(AK, model, katigoria, fueltype,k, r, f ,s, temp);
				tableSync();
				clearTextFields(true);
			}
		}

		if (event.getSource() == showVehicleBtn) {
			tableSync();
		}


		if (event.getSource() == searchVehicleBtn) {
			String sel = searchComboBox.getSelectionModel().getSelectedItem().toString();
			searchVehicle(sel);
		}


		if (event.getSource() == deleteVehicleBtn) {
			if (!tempAK.equals("")) { 
				deleteVehicle();
				tableSync();
				clearTextFields(true);
			}        
		}

		if (event.getSource() == vehicleTableView) {
			Vehicle selectedVehicle = vehicleTableView.getSelectionModel().getSelectedItem();
			if (selectedVehicle != null) {
				if( selectedVehicle instanceof Car ) {
					Car c = (Car) selectedVehicle;
					carrb.setSelected(true);
					fField.setText(c.getSeatsnumber()+"");
					sField.setText(c.getDoorsnumber()+"");	
				}else {
					TwoWheeled tw = (TwoWheeled) selectedVehicle;
					twowheelrb.setSelected(true);
					fField.setText(tw.getHeight()+"");
					sField.setText(tw.getPackageSystem()+"");
				}
				AKField.setText(selectedVehicle.getAK());
				modelField.setText(selectedVehicle.getModel());
				katigoriaField.setText(selectedVehicle.getKatigoria());
				fueltypeField.setText(selectedVehicle.getFuel());
				kybikaField.setText(selectedVehicle.getKybika()+"");
				rentCostField.setText(selectedVehicle.getRentCost()+"");
				tempAK = selectedVehicle.getAK();
			}
		} 

	}

	public void searchVehicle(String sel) {
		List<Vehicle> items = vehicleTableView.getItems();
		items.clear();
		for (Vehicle s : vehicleList) {
			if (sel.equals("Car") && s instanceof Car) {
				items.add(s);
			}else if (sel.equals("TwoWheeled") && s instanceof TwoWheeled) {
				items.add(s);
			}
		}
	}

	public void tableSync() {
		List<Vehicle> items = vehicleTableView.getItems();
		items.clear();
		for (Vehicle d : vehicleList) {
			items.add(d);
		}
	}

	public void updateVehicle(String AK, String model, String katigoria, String fuel, double kybika, double rentCost, String f, String s, boolean x) {
		for (int i = 0; i < vehicleList.size(); i++) {
			if (vehicleList.get(i).getAK().equals(tempAK)) {
				vehicleList.get(i).setModel(model);
				vehicleList.get(i).setKatigoria(katigoria);
				vehicleList.get(i).setFuel(fuel);
				vehicleList.get(i).setKybika(kybika);
				vehicleList.get(i).setRentCost(rentCost);
				if (x) {
					double ff = Double.parseDouble(f);
					TwoWheeled tw = (TwoWheeled) vehicleList.get(i); 
					tw.setHeight(ff);
					tw.setPackageSystem(s);
				} else {
					int ff = Integer.parseInt(f);
					int ss = Integer.parseInt(s);
					Car c = (Car) vehicleList.get(i);
					c.setSeatsnumber(ff);
					c.setDoorsnumber(ss);	
				}
				break;
			}
		}
	}

	public void deleteVehicle() {
		for (int i = 0; i < vehicleList.size(); i++) {
			if (vehicleList.get(i).getAK().equals(tempAK)) {
				vehicleList.remove(i);
				tempAK = "" ;
				break; 
			}
		}
	}

	public void clearTextFields(boolean x) {
		searchComboBox.getSelectionModel().selectFirst();
		AKField.setText("");
		modelField.setText("");
		katigoriaField.setText("");
		fueltypeField.setText("");
		kybikaField.setText("");
		rentCostField.setText("");
		fField.setText("");
		sField.setText("");
		if (x) twowheelrb.setSelected(true);
	}

}