import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import java.util.ArrayList;
import java.util.List;

public class CitySceneCreator extends SceneCreator implements EventHandler<MouseEvent> {
	
	int codetemp = -1; // exei to id ths epilegmenhs polhs 
	
	//  List of cities
    static ArrayList<City> cityList;
    //	Flow Pane
    FlowPane buttonFlowPane;
    //	Grid Panes
    GridPane rootGridPane, inputFieldsPane;
    //	Second Scene buttons
    Button  searchBtn, newCityBtn, updateCityBtn,showCityBtn ,deleteCityBtn, backBtn;
    //	Second scene labels
    Label nameLbl;
    //	Second scene TextFields
    TextField nameField;
    //	TableView
    TableView<City> cityTableView;
    
    public CitySceneCreator(double width, double height) {
        super(width, height);
        //  Initialize fields
        cityList = new ArrayList<>();
        rootGridPane = new GridPane();
        buttonFlowPane = new FlowPane();
        nameLbl = new Label("City ");
        nameField = new TextField();
        
        //dimiourgia buttons
        searchBtn = new Button("Search City");
        newCityBtn = new Button("New City");
        showCityBtn = new Button("Show All Cities");
        updateCityBtn = new Button("Update");
        deleteCityBtn = new Button("Delete");
        backBtn = new Button("Go Back");
        inputFieldsPane = new GridPane();
        cityTableView = new TableView<>();

        //  Attach events
        searchBtn.setOnMouseClicked(this);
        backBtn.setOnMouseClicked(this);
        newCityBtn.setOnMouseClicked(this);
        showCityBtn.setOnMouseClicked(this);
        updateCityBtn.setOnMouseClicked(this);
        deleteCityBtn.setOnMouseClicked(this);
        cityTableView.setOnMouseClicked(this);

        //  Customize buttonFlowPane
        buttonFlowPane.setHgap(10);
        buttonFlowPane.getChildren().add(showCityBtn);
        buttonFlowPane.getChildren().add(searchBtn);
        buttonFlowPane.getChildren().add(newCityBtn);
        buttonFlowPane.getChildren().add(updateCityBtn);
        buttonFlowPane.getChildren().add(deleteCityBtn);
        buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);

        // Customize inputFieldsPane
        inputFieldsPane.setAlignment(Pos.TOP_RIGHT);
        inputFieldsPane.setVgap(10);
        inputFieldsPane.setHgap(10);
        inputFieldsPane.add(nameLbl, 0, 0);
        inputFieldsPane.add(nameField, 1, 0);
        
        // Customize rootGridPane
        rootGridPane.setVgap(10);
        rootGridPane.setHgap(10);
        rootGridPane.add(inputFieldsPane, 1, 0);
        rootGridPane.add(cityTableView, 0, 0);
        rootGridPane.add(buttonFlowPane, 0, 2);
        rootGridPane.add(backBtn, 1, 2);

        //  Customize CityTableView
        TableColumn<City, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("cityName"));
        cityTableView.getColumns().add(nameColumn);

        TableColumn<City, String> codeColumn = new TableColumn<>("Code");
        codeColumn.setCellValueFactory(new PropertyValueFactory<>("cityCode"));
        cityTableView.getColumns().add(codeColumn);

    }

    @Override
    public Scene createScene() {
        return new Scene(rootGridPane, width, height);
    }

    @Override
    public void handle(MouseEvent event) {
        if (event.getSource() == backBtn) {
            Main.mainStage.setTitle("Car Rental Service ");
            Main.mainStage.setScene(Main.mainScene);
        }
       
        if (event.getSource() == showCityBtn) {
        	tableSync();
        }
        
        if (event.getSource() == newCityBtn) {
            String name = nameField.getText();
            if (name.length() == 0) return; //diavazw an exei periexomeno
            int code  = 1 ;		// paragw ton kwdiko ths neas polhs 	
            if (cityList.size() != 0) { //an h lista den einai kenh, 
            	//dinw sthn nea polh ton kwdiko ths teleftaias polhs poy
            	//yparxei sth lista ayximeno kata 1
            	code = cityList.get(cityList.size()-1).getCityCode() +1 ;
            }
            
            createCity(code, name);
            tableSync();
            clearTextFields();
        }

        if (event.getSource() == searchBtn) {
        	String name = nameField.getText();
        	if (name.length() == 0) return;
        		searchCity(name);
            }
        
        if (event.getSource() == updateCityBtn) {
            String name = nameField.getText();
            if (name.length() == 0) return;
            if (codetemp != -1 ) { //elegxw an o xristis exei epilexei mia polh
            	updateCity(name);
            	tableSync();
            	clearTextFields();
            }
        }
       
        if (event.getSource() == deleteCityBtn) {
        	if (codetemp != -1 ) { //elegxw an o xristis exei epilexei mia polh
        		deleteCity();
        		tableSync();
            	clearTextFields();
        	}
        }
        
        if (event.getSource() == cityTableView) {
            City selectedCity = cityTableView.getSelectionModel().getSelectedItem();
            if (selectedCity != null) { //otan o xristis epilexei mia polh apo ton pinaka
            	//pernaw tis plirofories ths polhs sta antistoixa pedia kai
            	//enimerwnw thn metabliti codetemp pou pairnei
            	//to id ths epilegmenhs polhs
                nameField.setText(selectedCity.getCityName());
                codetemp = selectedCity.getCityCode();
            }
        }
    }

    //oi methodoi pou xrhsimopoiountai otan pataei o xristsi kathe button
    
    public void createCity(int code, String name) {
        City c = new City(code , name);
        cityList.add(c);
    }


    public void tableSync() {
        List<City> items = cityTableView.getItems();
        items.clear();
        for (City c : cityList) items.add(c);    
    }
    
    public void updateCity(String name) {
    	for (int i = 0; i < cityList.size(); i++) {
            if (cityList.get(i).getCityCode() == codetemp) {
                cityList.get(i).setCityName(name);
            }
        }
    }

    public void deleteCity() {
        for (int i = 0; i < cityList.size(); i++) {
            if (cityList.get(i).getCityCode() == codetemp) {
                cityList.remove(i);
                StoreSceneCreator.deleteByCityCode(codetemp);
                codetemp = -1;
                break;
            }
        }
    }

    public void clearTextFields() {
        nameField.setText("");
        
    }
    
    public void searchCity(String name) {
    	List<City> items = cityTableView.getItems();
    	items.clear();
    	for (City c : cityList) {
    		if (c.getCityName().equals(name)) {
    			items.add(c);
    		}
    		
    	}
    }
    
}