import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import java.util.ArrayList;
import java.util.List;

public class RentalSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {
    //  List of rents
    ArrayList<Rental> rentalList;
    //	Flow Pane
    FlowPane buttonFlowPane;
    //	Grid Panes
    GridPane rootGridPane, inputFieldsPane;
    //	Second Scene buttons
    Button newRentalBtn, showRentalBtn, deleteRentalBtn, backBtn;
    //	Second scene labels
    Label nameLbl;
    //	Second scene TextFields
    TextField nameField;
    //	TableView
    TableView<Rental> rentalTableView;

    public RentalSceneCreator(double width, double height) {
        super(width, height);
        //  Initialize fields
        rentalList = new ArrayList<>();
        rootGridPane = new GridPane();
        buttonFlowPane = new FlowPane();
        nameLbl = new Label("Name: ");
        nameField = new TextField();
        
        newRentalBtn = new Button("New Rent");
        showRentalBtn = new Button("Show all rents");
        deleteRentalBtn = new Button("Delete");
        backBtn = new Button("Go Back");
        inputFieldsPane = new GridPane();
        rentalTableView = new TableView<>();

        //  Attach events
        backBtn.setOnMouseClicked(this);
        showRentalBtn.setOnMouseClicked(this);
        newRentalBtn.setOnMouseClicked(this);
        deleteRentalBtn.setOnMouseClicked(this);
        rentalTableView.setOnMouseClicked(this);

        //  Customize buttonFlowPane
        buttonFlowPane.setHgap(10);
        buttonFlowPane.getChildren().add(newRentalBtn);
        buttonFlowPane.getChildren().add(showRentalBtn);
        buttonFlowPane.getChildren().add(deleteRentalBtn);
        buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);

        // Customize inputFieldsPane
        inputFieldsPane.setAlignment(Pos.TOP_RIGHT);
        inputFieldsPane.setVgap(10);
        inputFieldsPane.setHgap(10);
        inputFieldsPane.add(nameLbl, 0, 0);
        inputFieldsPane.add(nameField, 1, 0);
        
        // Customize rootGridPane
        rootGridPane.setVgap(10);
        rootGridPane.setHgap(10);
        rootGridPane.add(inputFieldsPane, 1, 0);
        rootGridPane.add(rentalTableView, 0, 0);
        rootGridPane.add(buttonFlowPane, 0, 2);
        rootGridPane.add(backBtn, 1, 2);

        //  Customize dogTableView
        TableColumn<Rental, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        rentalTableView.getColumns().add(nameColumn);

    }

    @Override
    public Scene createScene() {
        return new Scene(rootGridPane, width, height);
    }

    @Override
    public void handle(MouseEvent event) {
        // edw o xristis kanei click se mia apo tis epiloges tou window
    	if (event.getSource() == backBtn) {
            Main.mainStage.setTitle("Car Rental Service ");
            Main.mainStage.setScene(Main.mainScene);
        }
        if (event.getSource() == newRentalBtn) {
            String name = nameField.getText();
            createRental(name);
            tableSync();
            clearTextFields();
        }
       
        if (event.getSource() == deleteRentalBtn) {
        	tableSync();
            clearTextFields();
        }
        if (event.getSource() == rentalTableView) {
        	Rental selectedRental = rentalTableView.getSelectionModel().getSelectedItem();
            if (selectedRental != null) {
                //nameField.setText(selectedRental.getName());
                
            }
        }
    }
    
    public void createRental(String name) {
    	
    }

    public void tableSync() {
        List<Rental> items = rentalTableView.getItems();
        items.clear();
        for (Rental d : rentalList) {
            if (d instanceof Rental) {
                items.add((Rental) d);
            }
        }
    }

    public void updateRental(String name, int age, String breed, char gender) {
        for (Rental d : rentalList) {
          //  if ((d.getName()).equals(name)) {
                
            }
       // }
    }

    public void deleteRental(String name) {
        for (int i = 0; i < rentalList.size(); i++) {
       //     if (rentalList.get(i).getName().equals(name)) {
            	rentalList.remove(i);
                break;
            }
        //}
    }

    public void clearTextFields() {
        nameField.setText("");
        
    }
}