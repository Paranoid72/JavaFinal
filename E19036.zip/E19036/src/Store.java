public class Store {

	private int storeCode; //dilosi metablhtwn
	private String storeName; 
	private City cityLocation; 

	//constructor
	public Store(int storeCode, String storeName, City cityLocation) {
		super();
		this.storeCode = storeCode;
		this.storeName = storeName;
		this.cityLocation = cityLocation;
	}
	//getters kai setters
	public int getStoreCode() {
		return storeCode;
	}

	public void setStoreCode(int storeCode) {
		this.storeCode = storeCode;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public City getCityLocation() {
		return cityLocation;
	}
	public void setCityLocation(City cityLocation) {
		this.cityLocation = cityLocation;
	}

}
