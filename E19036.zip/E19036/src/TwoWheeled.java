public class TwoWheeled extends Vehicle {

private double height; //dilosi metablhtwn
private String packageSystem; 

//constructor
public TwoWheeled(String AK, String model, String katigoria, String fuel, double kybika, double rentCost, double height,
		String packageSystem) {
	super(AK, model, katigoria, fuel , kybika, rentCost);
	this.height = height;
	this.packageSystem = packageSystem;
}

//getters kai setters
public double getHeight() {
	return height;
}
public void setHeight(double height) {
	this.height = height;
}
public String getPackageSystem() {
	return packageSystem;
}
public void setPackageSystem(String packageSystem) {
	this.packageSystem = packageSystem;
}

}