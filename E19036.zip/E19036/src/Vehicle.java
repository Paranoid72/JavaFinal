public class Vehicle {

//dilosi metablhtwn
private String AK; 
private String model; 
private String katigoria;
private String fuel;
private double kybika;
private double rentCost; 

//constructor
public Vehicle(String AK, String model, String katigoria, String fuel, double kybika, double rentCost) {
	this.AK = AK;
	this.model = model;
	this.katigoria = katigoria;
	this.fuel = fuel;
	this.kybika = kybika;
	this.rentCost = rentCost;
}

//getters kai setters
public String getFuel() {
	return fuel;
}

public void setFuel(String fuel) {
	this.fuel = fuel;
}
public String getAK() {
	return AK;
}

public void setAK(String AK) {
	this.AK = AK;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
public String getKatigoria() {
	return katigoria;
}
public void setKatigoria(String katigoria) {
	this.katigoria = katigoria;
}
public double getKybika() {
	return kybika;
}
public void setKybika(double kybika) {
	this.kybika = kybika;
}
public double getRentCost() {
	return rentCost;
}
public void setRentCost(double rentCost) {
	this.rentCost = rentCost;
}


}
