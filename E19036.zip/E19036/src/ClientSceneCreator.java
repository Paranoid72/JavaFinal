import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import java.util.ArrayList;
import java.util.List;

public class ClientSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {
	
	String ATtemp = "" ; //periexei ton arithmo taytotitas(AT) tou epilegmenou client
	
	//  List of clients
	static ArrayList<Client> clientList;
	//	Flow Pane
	FlowPane buttonFlowPane;
	//	Grid Panes
	GridPane rootGridPane, inputFieldsPane;
	//	Second Scene buttons
	Button newClientBtn, updateClientBtn, clearBtn,showClientBtn ,searchClientBtn , deleteClientBtn, backBtn;
	//	Second scene labels
	Label nameLbl, searchLbl,surnameLbl, ATLbl, adeiaLbl, emailLbl, addressLbl, phoneLbl;
	//	Second scene TextFields
	TextField nameField, searchField,surnameField, ATField, adeiaField, emailField, addressField, phoneField;
	//	TableView
	TableView<Client> clientTableView;

	public ClientSceneCreator(double width, double height) {
		super(width, height);
		
		clientList = new ArrayList<>();
		rootGridPane = new GridPane();
		buttonFlowPane = new FlowPane();

		nameLbl = new Label("Name: ");
		nameField = new TextField();
		
		// dimiourgia Labels kai Fields
		surnameLbl = new Label("Surname: ");
		surnameField = new TextField();		
		ATLbl = new Label("ID: ");
		ATField = new TextField();		
		adeiaLbl = new Label("License: ");
		adeiaField = new TextField();
		emailLbl = new Label("E-Mail: ");
		emailField = new TextField();
		addressLbl = new Label("Address: ");
		addressField = new TextField();
		phoneLbl = new Label("Phone: ");
		phoneField = new TextField();
		searchLbl = new Label("Search by ID: ");
		searchField = new TextField();
		
		// dimiourgia Buttons
		newClientBtn = new Button("New Client");
		clearBtn = new Button("Clear fields");
		updateClientBtn = new Button("Update");
		searchClientBtn = new Button("Search");
		showClientBtn = new Button("Show all");
		deleteClientBtn = new Button("Delete");
		backBtn = new Button("Go Back");
		inputFieldsPane = new GridPane();
		clientTableView = new TableView<>();

		//  Attach events
		backBtn.setOnMouseClicked(this);
		clearBtn.setOnMouseClicked(this);
		newClientBtn.setOnMouseClicked(this);
		searchClientBtn.setOnMouseClicked(this);
		showClientBtn.setOnMouseClicked(this);
		updateClientBtn.setOnMouseClicked(this);
		deleteClientBtn.setOnMouseClicked(this);
		clientTableView.setOnMouseClicked(this);

		//  Customize buttonFlowPane
		buttonFlowPane.setHgap(10);
		buttonFlowPane.getChildren().add(newClientBtn);
		buttonFlowPane.getChildren().add(searchClientBtn);
		buttonFlowPane.getChildren().add(showClientBtn);
		buttonFlowPane.getChildren().add(updateClientBtn);
		buttonFlowPane.getChildren().add(deleteClientBtn);
		buttonFlowPane.getChildren().add(clearBtn);
		buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);

		// Customize inputFieldsPane
		inputFieldsPane.setAlignment(Pos.TOP_RIGHT);
		inputFieldsPane.setVgap(10);
		inputFieldsPane.setHgap(10);
		inputFieldsPane.add(nameLbl, 0, 0);
		inputFieldsPane.add(nameField, 1, 0);		
		inputFieldsPane.add(surnameLbl, 0, 1);
		inputFieldsPane.add(surnameField, 1, 1);		
		inputFieldsPane.add(ATLbl, 0, 2);
		inputFieldsPane.add(ATField, 1, 2);
		inputFieldsPane.add(adeiaLbl, 0, 3);
		inputFieldsPane.add(adeiaField, 1, 3);
		inputFieldsPane.add(emailLbl, 0, 4);
		inputFieldsPane.add(emailField, 1, 4);
		inputFieldsPane.add(addressLbl, 0, 5);
		inputFieldsPane.add(addressField, 1, 5);
		inputFieldsPane.add(phoneLbl, 0, 6);
		inputFieldsPane.add(phoneField, 1, 6);
		inputFieldsPane.add(searchLbl, 1, 8);
		inputFieldsPane.add(searchField, 1, 9);
		
		// Customize rootGridPane
		rootGridPane.setVgap(10);
		rootGridPane.setHgap(10);
		rootGridPane.add(inputFieldsPane, 1, 0);
		rootGridPane.add(clientTableView, 0, 0);
		rootGridPane.add(buttonFlowPane, 0, 2);
		rootGridPane.add(backBtn, 1, 2);

		//  Customize dogTableView
		TableColumn<Client, String> nameColumn = new TableColumn<>("Name");
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("onoma"));
		clientTableView.getColumns().add(nameColumn);
		
		TableColumn<Client, String> surnameColumn = new TableColumn<>("Surname");
		surnameColumn.setCellValueFactory(new PropertyValueFactory<>("epitheto"));
		clientTableView.getColumns().add(surnameColumn);
		
		TableColumn<Client, String> ATColumn = new TableColumn<>("ID");
		ATColumn.setCellValueFactory(new PropertyValueFactory<>("AT"));
		clientTableView.getColumns().add(ATColumn);
		
		TableColumn<Client, String> adeiaColumn = new TableColumn<>("License");
		adeiaColumn.setCellValueFactory(new PropertyValueFactory<>("adeia"));
		clientTableView.getColumns().add(adeiaColumn);
		
		TableColumn<Client, String> emailColumn = new TableColumn<>("E-Mail");
		emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
		clientTableView.getColumns().add(emailColumn);
		
		TableColumn<Client, String> addressColumn = new TableColumn<>("Address");
		addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
		clientTableView.getColumns().add(addressColumn);
		
		TableColumn<Client, String> phoneColumn = new TableColumn<>("Phone");
		phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
		clientTableView.getColumns().add(phoneColumn);

	}

	@Override
	public Scene createScene() {
		return new Scene(rootGridPane, width, height);
	}

	@Override
	public void handle(MouseEvent event) {
		if (event.getSource() == backBtn) {
			Main.mainStage.setTitle("Car Rental Service ");
			Main.mainStage.setScene(Main.mainScene);
		}
		
		if (event.getSource() == clearBtn) {
			clearTextFields();
		}
		
		if (event.getSource() == newClientBtn) {
           
        	// edw diavazw ayta pou exei eisagei o xristis
        	String AT = ATField.getText();
            String onoma = nameField.getText();
            String epitheto = surnameField.getText();
            String adeia = adeiaField.getText();
            String address = addressField.getText();
            String email = emailField.getText();
            String phone = phoneField.getText();
           
         // edw elegxw an exoun simplirwthei ta pedia ayta
            if (AT.length() == 0) return; 
            if (onoma.length() == 0) return;
            if (epitheto.length() == 0) return;
            if (adeia.length() == 0) return;
            if (address.length() == 0) return;
            if (email.length() == 0) return;
            if (phone.length() == 0) return;
            
     // elegxw oti ta stoixeia pou eisagei o xristis einai monadika
            for(Client c : clientList) {
            	if (c.getAT().equals(AT) || c.getAdeia().equals(adeia)) {
            		return;
            	}
            }  
            createClient (AT, adeia, onoma, epitheto, email, address, phone);
            tableSync();
            clearTextFields();
        }
		
		// emfanizw olous tous pelates
        if (event.getSource() == showClientBtn) {
        	tableSync();
        }
        
        //edw ginetai to click sthn update
        if (event.getSource() == updateClientBtn) {
        	// kanei update ta pedia pou allazei o xristis
            String onoma = nameField.getText();
            String epitheto = surnameField.getText();
            String address = addressField.getText();
            String email = emailField.getText();
            String phone = phoneField.getText();
         
            if (onoma.length() == 0) return;
            if (epitheto.length() == 0) return;
            if (address.length() == 0) return;
            if (email.length() == 0) return;
            if (phone.length() == 0) return;
            
            if (!ATtemp.equals("")) {
            	updateClient(onoma, epitheto, address, email, phone);
            	tableSync();
            	clearTextFields();
            }
        }
		
        if (event.getSource() == searchClientBtn) {
        	String AT = searchField.getText();
        	if (AT.length() == 0) return;
        	searchClient(AT);
            
        }
        
        //edw ginetai diagrafh pelatwn
        if (event.getSource() == deleteClientBtn) {
            if (!ATtemp.equals("")) { 
				deleteClient();
				tableSync();
				clearTextFields();
			}
            
        }
        
        if (event.getSource() == clientTableView) {
        	Client selectedClient = clientTableView.getSelectionModel().getSelectedItem();
            if (selectedClient != null) {
            	nameField.setText(selectedClient.getOnoma());
             	adeiaField.setText(selectedClient.getAdeia());
                addressField.setText(selectedClient.getAddress());
                surnameField.setText(selectedClient.getEpitheto());
                ATField.setText(selectedClient.getAT());
                phoneField.setText(selectedClient.getPhone());
                emailField.setText(selectedClient.getEmail());
                ATtemp = selectedClient.getAT();
            }
        } 
	}

	
    public void createClient(String AT, String adeia, String onoma, String epitheto, String email, String address, String phone) {
    	Client d = new Client(AT, adeia , onoma , epitheto, email, address, phone);
    	clientList.add(d);
    }


    public void tableSync() {
        List<Client> items = clientTableView.getItems();
        items.clear();
        for (Client d : clientList) {
            if (d instanceof Client) {
                items.add((Client) d);
            }
        }
    }
    
    //edw ginetai h tropopoihsh twn pelatwn
    public void updateClient(String onoma, String epitheto,String address,String email,String phone) {
       	for (int i = 0; i < clientList.size(); i++) {
			if (clientList.get(i).getAT().equals(ATtemp)) {
				
				clientList.get(i).setOnoma(onoma);
				clientList.get(i).setEpitheto(epitheto);
				clientList.get(i).setAddress(address);
				clientList.get(i).setEmail(email);
				clientList.get(i).setPhone(phone);
				break;
			}
        }
    }

    public void deleteClient() {
        //svisimo pelatwn
    	for (int i = 0; i < clientList.size(); i++) {
            if (clientList.get(i).getAT().equals(ATtemp)) {
                clientList.remove(i);
                ATtemp = "" ;
                break; 
            }
        }
    }

    public void searchClient(String AT) {
		List<Client> items = clientTableView.getItems();
		items.clear();
		for (Client s : clientList) {
			if (s.getAT().startsWith(AT)) {
				items.add(s);
			}
		}
	}
    
    public void clearTextFields() {
 
    	// katharismos olwn twn pediwn
    	adeiaField.setText("");
        nameField.setText("");
        addressField.setText("");
        surnameField.setText("");
        ATField.setText("");
        phoneField.setText("");
        emailField.setText("");
        searchField.setText("");
    }
	 
}