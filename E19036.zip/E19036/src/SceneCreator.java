import javafx.scene.Scene;

public abstract class SceneCreator {
	//mikos kai platos tou window 
	double width , height;
	//constructor
	public SceneCreator(double width , double height) {
		this.width = width;
		this.height = height;
	}

	abstract Scene createScene();
}
