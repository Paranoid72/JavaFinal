public class Car extends Vehicle {

private int seatsnumber;  //dilosi metablhtwn
private int doorsnumber; 

//constructor
public Car(String AK, String model, String katigoria, String fuel, double kybika, double rentCost, int seatsnumber, int doorsnumber) {
	super(AK, model, katigoria, fuel , kybika, rentCost);
	this.seatsnumber = seatsnumber;
	this.doorsnumber = doorsnumber;
}

//getters kai setters
public int getSeatsnumber() {
	return seatsnumber;
}

public void setSeatsnumber(int seatsnumber) {
	this.seatsnumber = seatsnumber;
}
public int getDoorsnumber() {
	return doorsnumber;
}
public void setDoorsnumber(int doorsnumber) {
	this.doorsnumber = doorsnumber;
}
	
}