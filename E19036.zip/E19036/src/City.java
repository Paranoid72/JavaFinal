public class City  {

	private int cityCode; //dilosi metablhtwn
	private String cityName; 

// getters kai setters
	public int getCityCode() {
		return cityCode;
	}
	public City(int cityCode, String cityName) {
		super();
		this.cityCode = cityCode;
		this.cityName = cityName;
	}
	public void setCityCode(int cityCode) {
		this.cityCode = cityCode;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
//emfanisi kodikou kai onomatos polis
	public String toString(){
		return cityCode + " - " + cityName;
	}

}