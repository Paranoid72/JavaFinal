import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;

public class StoreSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {

	int codetemp = -1; //periexei to code tou epilegmenou magaziou

	//  List of stores
	static ArrayList<Store> storeList;
	//	Flow Pane
	FlowPane buttonFlowPane;
	//	Grid Panes
	GridPane rootGridPane, inputFieldsPane;
	//	Second Scene buttons
	Button newStoreBtn, updateStoreBtn, searchStoreBtn, showStoreBtn ,deleteStoreBtn, backBtn;
	//	Second scene labels
	Label nameLbl, cityLbl ,searchLbl,codeLbl ;
	//	Second scene TextFields
	TextField nameField, searchField;
	//	TableView
	static TableView<Store> storeTableView;

	static ComboBox cityComboBox; //periexei tis poleis pou exoun dimiourgithei

	public StoreSceneCreator(double width, double height) {
		super(width, height);

		cityComboBox =  new ComboBox(FXCollections.observableArrayList(CitySceneCreator.cityList));

		//  Initialize fields
		storeList = new ArrayList<>();
		rootGridPane = new GridPane();
		buttonFlowPane = new FlowPane();
		nameLbl = new Label("Store: ");
		nameField = new TextField();
		searchField = new TextField();
		cityLbl = new Label("City: ");
		searchLbl = new Label("Search by city name: ");

		newStoreBtn = new Button("New Store");
		showStoreBtn = new Button("Show All Stores");
		searchStoreBtn = new Button("Search");
		updateStoreBtn = new Button("Update");
		deleteStoreBtn = new Button("Delete");
		backBtn = new Button("Go Back");
		inputFieldsPane = new GridPane();
		storeTableView = new TableView<>();

		//  Attach events
		backBtn.setOnMouseClicked(this);
		newStoreBtn.setOnMouseClicked(this);
		searchStoreBtn.setOnMouseClicked(this);
		showStoreBtn.setOnMouseClicked(this);
		updateStoreBtn.setOnMouseClicked(this);
		deleteStoreBtn.setOnMouseClicked(this);
		storeTableView.setOnMouseClicked(this);

		//  Customize buttonFlowPane
		buttonFlowPane.setHgap(10);
		buttonFlowPane.getChildren().add(newStoreBtn);
		buttonFlowPane.getChildren().add(searchStoreBtn);
		buttonFlowPane.getChildren().add(showStoreBtn);
		buttonFlowPane.getChildren().add(updateStoreBtn);
		buttonFlowPane.getChildren().add(deleteStoreBtn);
		buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);

		// Customize inputFieldsPane
		inputFieldsPane.setAlignment(Pos.TOP_RIGHT);
		inputFieldsPane.setVgap(10);
		inputFieldsPane.setHgap(10);
		inputFieldsPane.add(nameLbl, 0, 0);
		inputFieldsPane.add(nameField, 1, 0);
		inputFieldsPane.add(cityLbl, 0, 1);
		inputFieldsPane.add(cityComboBox, 1, 1);
		inputFieldsPane.add(searchLbl, 1, 2);
		inputFieldsPane.add(searchField, 1, 3);

		// Customize rootGridPane
		//		rootScene2.setGridLinesVisible(true);
		rootGridPane.setVgap(10);
		rootGridPane.setHgap(10);
		rootGridPane.add(inputFieldsPane, 1, 0);
		rootGridPane.add(storeTableView, 0, 0);
		rootGridPane.add(buttonFlowPane, 0, 2);
		rootGridPane.add(backBtn, 1, 2);

		//  Customize storeTableView
		TableColumn<Store, String> nameColumn = new TableColumn<>("Name");
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("storeName"));
		storeTableView.getColumns().add(nameColumn);

		TableColumn<Store, String> codeColumn = new TableColumn<>("Code");
		codeColumn.setCellValueFactory(new PropertyValueFactory<>("storeCode"));
		storeTableView.getColumns().add(codeColumn);

		TableColumn<Store, String> cityColumn = new TableColumn<>("City");
		cityColumn.setCellValueFactory(new PropertyValueFactory<>("cityLocation"));
		storeTableView.getColumns().add(cityColumn);

	}

	@Override
	public Scene createScene() {
		return new Scene(rootGridPane, width, height);
	}

	@Override
	public void handle(MouseEvent event) {
		if (event.getSource() == backBtn) {
			Main.mainStage.setTitle("Car Rental Service ");
			Main.mainStage.setScene(Main.mainScene);
		}

		if (event.getSource() == showStoreBtn) {
			tableSync();
		}

		if (event.getSource() == newStoreBtn) {
			String name = nameField.getText();
			if (name.length() == 0) return; 
			int code = 1 ;
			if (storeList.size() != 0) {
				code = storeList.get(storeList.size()-1).getStoreCode() +1 ;
			}
			String city = cityComboBox.getSelectionModel().getSelectedItem().toString();
			int cityCode = Integer.parseInt(city.split(" - ")[0]);
			City c2 = null;
			for (City c : CitySceneCreator.cityList) {
				if (c.getCityCode() == cityCode) c2 = c;        			
			}
			if (c2 == null ) return;
			createStore(code, name, c2);
			tableSync();
			clearTextFields();
		}
		// edw ginetai yo click gia thn search
		if (event.getSource() == searchStoreBtn) {
			String name = searchField.getText();
			if (name.length() == 0) return;
			searchStore(name);
		}
		//edw ginetai to click gia to delete
		if (event.getSource() == deleteStoreBtn) {
			if (codetemp != -1 ) { 
				deleteStore();
				tableSync();
				clearTextFields();
			}
		}
		
		if (event.getSource() == storeTableView) {
			Store selected = storeTableView.getSelectionModel().getSelectedItem();
			if (selected != null) {
				nameField.setText(selected.getStoreName());
				codetemp = selected.getStoreCode();
				String temp = selected.getCityLocation().getCityName();
				searchField.setText(temp);
				cityComboBox.getSelectionModel().select(selected.getCityLocation().toString());
			}

		}

		if (event.getSource() == updateStoreBtn) {
			String name = nameField.getText();
			if (name.length() == 0) return;
			if (codetemp != -1 ) {
				updateStore(name);
				tableSync();
				clearTextFields();
			}
		}

	}

	public void createStore(int storeCode, String storeName, City cityLocation) {
		Store d = new Store(storeCode, storeName, cityLocation);
		storeList.add(d);
	}
	//edw ginetai i anazitisi katastimatwn
	public void searchStore(String cityName) {
		List<Store> items = storeTableView.getItems();
		items.clear();
		for (Store s : storeList) {
			if (s.getCityLocation().getCityName().startsWith(cityName)) {
				items.add(s);
			}
		}
	}

	static public void tableSync() {
		List<Store> items = storeTableView.getItems();
		items.clear();
		for (Store d : storeList) {
			if (d instanceof Store) {
				items.add((Store) d);
			}
		}
	}
	// edw ginetai h tropopoihsh twn katastimatwn
	public void updateStore(String storeName) {
		for (int i = 0; i < storeList.size(); i++) {
			if (storeList.get(i).getStoreCode() == codetemp) {
				storeList.get(i).setStoreName(storeName);
			}
		}
	}

	public void deleteStore() {
		for (int i = 0; i < storeList.size(); i++) {
			if (storeList.get(i).getStoreCode() == codetemp) {
				storeList.remove(i);
				codetemp = -1;
				break;
			}
		}
	}

	public void clearTextFields() {
		nameField.setText("");
		searchField.setText("");
		cityComboBox.getSelectionModel().selectFirst();

	} 

	public static void updateCityCombo() { //enimerwnw to combobox kathe fora pou pataw to koumpi store
		
		cityComboBox.getItems().clear();
		for(City c : CitySceneCreator.cityList) {
			cityComboBox.getItems().add(c.getCityCode()+" - "+c.getCityName()); //xanapernaw tis poleis sto combobox
		}
	}
	// edw ginetai h diagrafh katastimatwn otan diagrafw thn polh pou einai me dedomeno to id
	public static void deleteByCityCode(int code) {
		for (int i = 0; i < storeList.size(); i++) {
			if (storeList.get(i).getCityLocation().getCityCode() == code) { //gia kathe magazi pou uparxei elegxw
				//an uparxei sthn polh pou diagrafhke
				//kai meiwnw kata 1 ton kwdiko ths polhs
				storeList.remove(i);
				i--;
			}
		}
		tableSync();
	}

}